using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public float speed = 2f;

    private bool collected = false;

    void Update()
    {
        transform.position += Vector3.down * speed * Time.deltaTime;

        if (transform.position.y < -6f)
        {
            Destroy(gameObject);
        }
    }

    public void Collect(GameObject player)
    {
        if (collected) return;

        collected = true;

        // Rewards
        GameManager.instance.AddScore(5);
        GameManager.instance.AddLife(1);

        // Play sound
        GameManager.instance.PlayPowerUpSound();

        // Activate double shot
        PlayerMovement pm = player.GetComponent<PlayerMovement>();
        if (pm != null)
        {
            pm.ActivateDoubleShot();
        }

        Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Collect(other.gameObject);
        }
    }
}