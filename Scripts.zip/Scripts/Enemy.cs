using UnityEngine;

public class Enemy : MonoBehaviour
{
    // Vertical movement speed

    public float speed = 2f;

    // Position where enemy disappears
    // and damages player

    public float bottomLimit = -5f;

    // Horizontal movement settings
    // Used for wave / zig-zag movement

    public float horizontalSpeed = 1f;

    public float waveFrequency = 2f;

    private bool hasDamaged = false;

    // Store initial X position

    private float startX;

    void Start()
    {
        // Save starting position

        startX =
            transform.position.x;

        // Add slight random rotation
        // for visual variation

        float randomRotation =
            Random.Range(
                -20f,
                20f
            );

        transform.rotation =
            Quaternion.Euler(
                0f,
                0f,
                randomRotation
            );
    }

    void Update()
    {
        // Move downward

        float newY =
            transform.position.y -
            speed *
            Time.deltaTime;

        // Create wave movement

        float offsetX =
            Mathf.Sin(
                Time.time *
                waveFrequency
            ) *
            horizontalSpeed;

        float newX =
            startX +
            offsetX;

        // Apply movement

        transform.position =
            new Vector3(
                newX,
                newY,
                0f
            );

        // Enemy reaches bottom

        if (
            transform.position.y <
            bottomLimit &&
            !hasDamaged
        )
        {
            hasDamaged = true;

            GameManager.instance
                .TakeDamage(1);

            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(
        Collider2D other)
    {
        // Enemy collides with player

        if (
            other.CompareTag(
                "Player"
            ) &&
            !hasDamaged
        )
        {
            hasDamaged = true;

            GameManager.instance
                .TakeDamage(1);

            Destroy(gameObject);
        }
    }
}