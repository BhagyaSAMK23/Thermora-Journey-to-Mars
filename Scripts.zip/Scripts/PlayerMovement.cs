using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    // Horizontal movement speed

    public float moveSpeed = 5f;

    // Bullet prefab and spawn point

    public GameObject bulletPrefab;
    public Transform firePoint;

    [Header("Shooting")]

    // Time between shots

    public float fireRate = 0.3f;

    private float nextFireTime = 0f;

    [Header("Bullet Colors")]

    // Different bullet colors for upgrades

    public Color normalBulletColor = Color.cyan;
    public Color doubleShotBulletColor = Color.yellow;
    public Color sideBulletColor = Color.magenta;

    [Header("Overheat System")]

    // Heat values for shooting system

    public float heat = 0f;

    public float heatPerShot = 20f;

    public float maxHeat = 100f;

    public float coolDownSpeed = 25f;

    // Time player must wait after overheating

    public float overheatedCooldownTime = 6f;

    private bool overheated = false;

    private float overheatEndTime = 0f;

    [Header("PowerUp")]

    // Double shot state and duration

    public bool doubleShotActive = false;

    public float powerUpDuration = 5f;

    [Header("Upgrade")]

    // Unlocks additional shots

    public bool sideShotUnlocked = false;

    [Header("Shield Visual")]

    // Visual shield settings

    public GameObject shieldVisual;

    public float shieldBaseScale = 2f;

    public float shieldRotateSpeed = 120f;

    public float shieldPulseSpeed = 5f;

    public float shieldPulseAmount = 0.15f;

    void Update()
    {
        // Execute player systems every frame

        Move();

        CoolHeat();

        Shoot();

        UpdateShieldVisual();

        // Update heat UI

        if (GameManager.instance != null)
        {
            GameManager.instance.UpdateHeatUI(
                heat,
                maxHeat,
                overheated
            );
        }
    }

    // Handle left/right movement

    void Move()
    {
        float moveInput = 0f;

        if (
            Input.GetKey(KeyCode.A) ||
            Input.GetKey(KeyCode.LeftArrow)
        )
        {
            moveInput = -1f;
        }

        if (
            Input.GetKey(KeyCode.D) ||
            Input.GetKey(KeyCode.RightArrow)
        )
        {
            moveInput = 1f;
        }

        transform.position +=
            Vector3.right *
            moveInput *
            moveSpeed *
            Time.deltaTime;
    }

    // Shooting system and overheating logic

    void Shoot()
    {
        if (overheated)
        {
            // Recover after cooldown

            if (Time.time >= overheatEndTime)
            {
                overheated = false;

                heat = 50f;
            }

            return;
        }

        if (
            Input.GetKey(KeyCode.Space) &&
            Time.time >= nextFireTime
        )
        {
            FireBullet();

            heat += heatPerShot;

            // Trigger overheat

            if (heat >= maxHeat)
            {
                overheated = true;

                overheatEndTime =
                    Time.time +
                    overheatedCooldownTime;

                heat = maxHeat;
            }

            nextFireTime =
                Time.time +
                fireRate;
        }
    }

    // Create bullets depending on upgrades

    void FireBullet()
    {
        // Double shot powerup

        if (doubleShotActive)
        {
            GameObject leftDoubleBullet =
                Instantiate(
                    bulletPrefab,
                    firePoint.position +
                    Vector3.left * 0.3f,
                    Quaternion.identity
                );

            GameObject rightDoubleBullet =
                Instantiate(
                    bulletPrefab,
                    firePoint.position +
                    Vector3.right * 0.3f,
                    Quaternion.identity
                );

            SetBulletColor(
                leftDoubleBullet,
                doubleShotBulletColor
            );

            SetBulletColor(
                rightDoubleBullet,
                doubleShotBulletColor
            );
        }
        else
        {
            GameObject bullet =
                Instantiate(
                    bulletPrefab,
                    firePoint.position,
                    Quaternion.identity
                );

            SetBulletColor(
                bullet,
                normalBulletColor
            );
        }

        // Additional side or diagonal shots

        if (sideShotUnlocked)
        {
            GameObject leftBullet =
                Instantiate(
                    bulletPrefab,
                    firePoint.position,
                    Quaternion.identity
                );

            GameObject rightBullet =
                Instantiate(
                    bulletPrefab,
                    firePoint.position,
                    Quaternion.identity
                );

            Bullet leftScript =
                leftBullet.GetComponent<Bullet>();

            Bullet rightScript =
                rightBullet.GetComponent<Bullet>();

            // Level 3 upgrades to diagonal shooting

            if (
                GameManager.instance != null &&
                GameManager.instance.level >= 3
            )
            {
                if (leftScript != null)
                {
                    leftScript.direction =
                        new Vector3(
                            -0.5f,
                            1f,
                            0f
                        ).normalized;
                }

                if (rightScript != null)
                {
                    rightScript.direction =
                        new Vector3(
                            0.5f,
                            1f,
                            0f
                        ).normalized;
                }
            }

            // Level 2 uses side shooting

            else
            {
                if (leftScript != null)
                {
                    leftScript.direction =
                        Vector3.left;
                }

                if (rightScript != null)
                {
                    rightScript.direction =
                        Vector3.right;
                }
            }

            SetBulletColor(
                leftBullet,
                sideBulletColor
            );

            SetBulletColor(
                rightBullet,
                sideBulletColor
            );
        }

        // Play shooting sound

        GameManager.instance.PlayShootSound();
    }

    // Apply bullet color

    void SetBulletColor(
        GameObject bullet,
        Color color)
    {
        SpriteRenderer spriteRenderer =
            bullet.GetComponent<SpriteRenderer>();

        if (spriteRenderer != null)
        {
            spriteRenderer.color =
                color;
        }
    }

    // Reduce heat over time

    void CoolHeat()
    {
        if (
            !overheated &&
            heat > 0f
        )
        {
            heat -=
                coolDownSpeed *
                Time.deltaTime;

            if (heat < 0f)
            {
                heat = 0f;
            }
        }
    }

    // Control shield animation and visibility

    void UpdateShieldVisual()
    {
        if (shieldVisual == null)
            return;

        if (
            GameManager.instance != null &&
            GameManager.instance.shieldHits > 0
        )
        {
            if (!shieldVisual.activeSelf)
            {
                shieldVisual.SetActive(true);
            }

            shieldVisual.transform.Rotate(
                0f,
                0f,
                shieldRotateSpeed *
                Time.deltaTime
            );

            float pulse =
                1f +
                Mathf.Sin(
                    Time.time *
                    shieldPulseSpeed
                ) *
                shieldPulseAmount;

            shieldVisual.transform.localScale =
                Vector3.one *
                shieldBaseScale *
                pulse;
        }
        else
        {
            if (shieldVisual.activeSelf)
            {
                shieldVisual.SetActive(false);
            }
        }
    }

    // Unlock side shooting upgrade

    public void UnlockSideShot()
    {
        sideShotUnlocked = true;
    }

    // Activate powerup shooting mode

    public void ActivateDoubleShot()
    {
        StopAllCoroutines();

        StartCoroutine(
            DoubleShotRoutine()
        );
    }

    // Double shot duration timer

    System.Collections.IEnumerator DoubleShotRoutine()
    {
        doubleShotActive = true;

        yield return new WaitForSeconds(
            powerUpDuration
        );

        doubleShotActive = false;
    }
}