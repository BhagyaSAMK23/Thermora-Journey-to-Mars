using UnityEngine;
using UnityEngine.EventSystems;

public class ButtonEffect : MonoBehaviour,
    IPointerEnterHandler,
    IPointerExitHandler
{
    // Store original button size

    private Vector3 originalScale;

    void Start()
    {
        // Save initial scale

        originalScale =
            transform.localScale;
    }

    // Triggered when mouse enters button area

    public void OnPointerEnter(
        PointerEventData eventData)
    {
        // Slightly enlarge button

        transform.localScale =
            originalScale * 1.1f;
    }

    // Triggered when mouse leaves button area

    public void OnPointerExit(
        PointerEventData eventData)
    {
        // Restore original size

        transform.localScale =
            originalScale;
    }
}