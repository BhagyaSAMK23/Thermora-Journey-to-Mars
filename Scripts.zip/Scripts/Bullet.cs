using UnityEngine;

public class Bullet : MonoBehaviour
{
    // Bullet movement speed

    public float speed = 10f;

    // Explosion effect prefab

    public GameObject explosionPrefab;

    // Bullet movement direction
    // Default is upward

    public Vector3 direction = Vector3.up;

    void Update()
    {
        // Move bullet every frame

        transform.position +=
            direction *
            speed *
            Time.deltaTime;

        // Remove bullets when outside screen area

        if (
            transform.position.y > 6f ||
            transform.position.y < -6f ||
            transform.position.x > 9f ||
            transform.position.x < -9f
        )
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Bullet hits enemy

        if (other.CompareTag("Enemy"))
        {
            // Increase score

            GameManager.instance.AddScore(1);

            // Play explosion sound

            GameManager.instance.PlayExplosionSound();

            // Spawn explosion effect

            if (explosionPrefab != null)
            {
                Instantiate(
                    explosionPrefab,
                    other.transform.position,
                    Quaternion.identity
                );
            }

            // Remove enemy and bullet

            Destroy(other.gameObject);

            Destroy(gameObject);
        }

        // Bullet hits powerup

        if (other.CompareTag("PowerUp"))
        {
            PowerUp powerUp =
                other.GetComponent<PowerUp>();

            if (powerUp != null)
            {
                // Find player and trigger collection

                GameObject player =
                    GameObject.FindGameObjectWithTag(
                        "Player"
                    );

                powerUp.Collect(player);
            }

            // Remove bullet

            Destroy(gameObject);
        }
    }
}