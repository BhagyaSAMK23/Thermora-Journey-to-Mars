using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    // Singleton access

    public static GameManager instance;

    [Header("Score")]

    public int score = 0;
    public TextMeshProUGUI scoreText;

    [Header("Level")]

    public int level = 1;
    public TextMeshProUGUI levelText;

    [Header("Lives")]

    public int lives = 3;

    // Maximum amount of lives allowed

    public int maxLives = 5;

    public TextMeshProUGUI livesText;

    [Header("Shield")]

    public int shieldHits = 0;

    public TextMeshProUGUI shieldText;

    // Next score milestone for shields

    private int nextShieldScore = 100;

    [Header("Heat")]

    public TextMeshProUGUI heatText;

    [Header("UI Panels")]

    public GameObject gameOverUI;
    public GameObject winPanel;

    [Header("Screen Feedback")]

    public DamageFlash damageFlash;

    private bool isGameOver = false;
    private bool hasWon = false;
    private bool sideShotUnlocked = false;

    [Header("Sounds")]

    public AudioSource audioSource;

    public AudioClip shootSound;
    public AudioClip explosionSound;
    public AudioClip powerUpSound;
    public AudioClip gameOverSound;
    public AudioClip winSound;

    void Awake()
    {
        instance = this;
    }

    void Start()
    {
        Time.timeScale = 1f;

        UpdateLevel();
        UpdateUI();

        // Hide panels at start

        if (gameOverUI != null)
            gameOverUI.SetActive(false);

        if (winPanel != null)
            winPanel.SetActive(false);
    }

    void Update()
    {
        // Restart game after win or game over

        if ((isGameOver || hasWon) &&
            Input.GetKeyDown(KeyCode.R))
        {
            Time.timeScale = 1f;

            SceneManager.LoadScene(
                SceneManager.GetActiveScene().buildIndex
            );
        }
    }

    // Add score and update progression

    public void AddScore(int amount)
    {
        if (isGameOver || hasWon)
            return;

        score += amount;

        CheckMilestones();

        UpdateLevel();

        UpdateUI();
    }

    // Check score milestones

    void CheckMilestones()
    {
        // Give shields every 100 score

        while (score >= nextShieldScore)
        {
            shieldHits++;

            nextShieldScore += 100;
        }

        // Unlock side shooting

        if (score >= 200 &&
            !sideShotUnlocked)
        {
            sideShotUnlocked = true;

            PlayerMovement player =
                FindAnyObjectByType<PlayerMovement>();

            if (player != null)
            {
                player.UnlockSideShot();
            }
        }

        // Win condition

        if (score >= 1000 &&
            !hasWon)
        {
            WinGame();
        }
    }

    // Update displayed level

    void UpdateLevel()
    {
        if (score >= 500)
        {
            level = 3;
        }
        else if (score >= 200)
        {
            level = 2;
        }
        else
        {
            level = 1;
        }
    }

    // Add lives with maximum limit

    public void AddLife(int amount)
    {
        if (isGameOver || hasWon)
            return;

        lives += amount;

        // Prevent lives exceeding limit

        if (lives > maxLives)
        {
            lives = maxLives;
        }

        UpdateUI();
    }

    // Apply damage

    public void TakeDamage(int amount)
    {
        if (isGameOver || hasWon)
            return;

        // Flash screen feedback

        if (damageFlash != null)
        {
            damageFlash.Flash();
        }

        // Shields absorb damage first

        if (shieldHits > 0)
        {
            shieldHits--;

            UpdateUI();

            return;
        }

        lives -= amount;

        UpdateUI();

        if (lives <= 0)
        {
            GameOver();
        }
    }

    // Update overheating UI

    public void UpdateHeatUI(
        float heat,
        float maxHeat,
        bool overheated)
    {
        if (heatText == null)
            return;

        if (overheated)
        {
            heatText.text =
                "Heat: OVERHEATED";
        }
        else
        {
            heatText.text =
                "Heat: " +
                Mathf.RoundToInt(
                    (heat / maxHeat) * 100f
                ) +
                "%";
        }
    }

    // Trigger game over

    void GameOver()
    {
        isGameOver = true;

        if (gameOverUI != null)
        {
            gameOverUI.SetActive(true);
        }

        PlayGameOverSound();

        Time.timeScale = 0f;
    }

    // Trigger victory

    void WinGame()
    {
        hasWon = true;

        if (winPanel != null)
        {
            winPanel.SetActive(true);
        }

        PlayWinSound();

        Time.timeScale = 0f;
    }

    // Refresh all UI elements

    void UpdateUI()
    {
        if (scoreText != null)
        {
            scoreText.text =
                "Score: " + score;
        }

        if (levelText != null)
        {
            levelText.text =
                "Level: " + level;
        }

        if (livesText != null)
        {
            livesText.text =
                "Lives: " + lives;
        }

        if (shieldText != null)
        {
            shieldText.text =
                "Shield: " + shieldHits;
        }
    }

    // Return to main menu

    public void GoToMainMenu()
    {
        Time.timeScale = 1f;

        SceneManager.LoadScene(
            "MainMenu"
        );
    }

    // Sound functions

    public void PlayShootSound()
    {
        if (audioSource != null &&
            shootSound != null)
        {
            audioSource.PlayOneShot(
                shootSound
            );
        }
    }

    public void PlayExplosionSound()
    {
        if (audioSource != null &&
            explosionSound != null)
        {
            audioSource.PlayOneShot(
                explosionSound
            );
        }
    }

    public void PlayPowerUpSound()
    {
        if (audioSource != null &&
            powerUpSound != null)
        {
            audioSource.PlayOneShot(
                powerUpSound
            );
        }
    }

    public void PlayGameOverSound()
    {
        if (audioSource != null &&
            gameOverSound != null)
        {
            audioSource.PlayOneShot(
                gameOverSound
            );
        }
    }

    public void PlayWinSound()
    {
        if (audioSource != null &&
            winSound != null)
        {
            audioSource.PlayOneShot(
                winSound
            );
        }
    }
}