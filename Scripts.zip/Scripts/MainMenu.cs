using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    // Reference to instructions UI panel

    public GameObject instructionsPanel;

    // Load gameplay scene

    public void StartGame()
    {
        SceneManager.LoadScene(
            "GameScene"
        );
    }

    // Exit game

    public void QuitGame()
    {
        Debug.Log(
            "Quit button pressed"
        );

#if UNITY_EDITOR

        // Stop play mode inside editor

        UnityEditor.EditorApplication
            .isPlaying = false;

#else

        // Close built application

        Application.Quit();

#endif
    }

    // Show instructions panel

    public void ShowInstructions()
    {
        if (instructionsPanel != null)
        {
            instructionsPanel
                .SetActive(true);
        }
    }

    // Hide instructions panel

    public void HideInstructions()
    {
        if (instructionsPanel != null)
        {
            instructionsPanel
                .SetActive(false);
        }
    }
}