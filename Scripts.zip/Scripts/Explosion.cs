using UnityEngine;

public class Explosion : MonoBehaviour
{
    // How long explosion remains visible

    public float duration = 0.3f;

    // Speed of expansion effect

    public float growSpeed = 4f;

    void Update()
    {
        // Increase explosion size continuously

        transform.localScale +=
            Vector3.one *
            growSpeed *
            Time.deltaTime;
    }

    void Start()
    {
        // Automatically remove explosion
        // after duration ends

        Destroy(
            gameObject,
            duration
        );
    }
}