using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [Header("Prefabs")]

    public GameObject enemyPrefab;
    public GameObject powerUpPrefab;

    [Header("Spawning")]

    // Time between enemy spawns

    public float spawnRate = 1.3f;

    // Lowest allowed spawn interval

    public float minimumSpawnRate = 0.9f;

    // Time between difficulty increases

    public float difficultyIncreaseTime = 10f;

    // How much spawn interval decreases

    public float spawnRateDecrease = 0.05f;

    [Header("PowerUp")]

    public float powerUpChance = 0.20f;

    [Header("Enemy Difficulty")]

    // Base difficulty increase amount

    public float enemySpeed = 0.8f;

    public float enemySpeedIncrease = 0.08f;

    [Header("Enemy Speed Types")]

    // Different enemy movement speeds

    public float slowEnemySpeed = 1.2f;

    public float normalEnemySpeed = 1.7f;

    public float fastEnemySpeed = 2.3f;

    [Header("Enemy Size")]

    public float minEnemyScale = 0.12f;

    public float maxEnemyScale = 0.18f;

    private float nextSpawnTime = 0f;

    private float nextDifficultyTime = 0f;

    private float lastSpawnX = 0f;

    void Start()
    {
        nextSpawnTime =
            Time.time + spawnRate;

        nextDifficultyTime =
            Time.time + difficultyIncreaseTime;
    }

    void Update()
    {
        SpawnTimer();

        DifficultyTimer();
    }

    // Controls spawning timing

    void SpawnTimer()
    {
        if (Time.time >= nextSpawnTime)
        {
            SpawnEnemy();

            // Random chance to spawn powerup

            if (
                powerUpPrefab != null &&
                Random.value < powerUpChance
            )
            {
                SpawnPowerUp();
            }

            nextSpawnTime =
                Time.time + spawnRate;
        }
    }

    // Controls difficulty progression

    void DifficultyTimer()
    {
        if (Time.time >= nextDifficultyTime)
        {
            IncreaseDifficulty();

            nextDifficultyTime =
                Time.time + difficultyIncreaseTime;
        }
    }

    // Gradually increase challenge

    void IncreaseDifficulty()
    {
        spawnRate -= spawnRateDecrease;

        if (spawnRate < minimumSpawnRate)
        {
            spawnRate =
                minimumSpawnRate;
        }

        slowEnemySpeed += enemySpeedIncrease;

        normalEnemySpeed += enemySpeedIncrease;

        fastEnemySpeed += enemySpeedIncrease;

        Debug.Log(
            "Difficulty Increased"
        );
    }

    // Spawn enemy with random properties

    void SpawnEnemy()
    {
        float randomX =
            GetBetterSpawnX();

        Vector3 spawnPosition =
            new Vector3(
                randomX,
                5f,
                0f
            );

        GameObject enemy =
            Instantiate(
                enemyPrefab,
                spawnPosition,
                Quaternion.identity
            );

        float chosenSpeed =
            ChooseEnemySpeed();

        // Random size variation

        float randomScale =
            Random.Range(
                minEnemyScale,
                maxEnemyScale
            );

        enemy.transform.localScale =
            new Vector3(
                randomScale,
                randomScale,
                1f
            );

        Enemy enemyScript =
            enemy.GetComponent<Enemy>();

        if (enemyScript != null)
        {
            enemyScript.speed =
                chosenSpeed;
        }
    }

    // Randomly choose enemy speed type

    float ChooseEnemySpeed()
    {
        int enemyType =
            Random.Range(0, 3);

        if (enemyType == 0)
        {
            return slowEnemySpeed;
        }

        if (enemyType == 1)
        {
            return normalEnemySpeed;
        }

        return fastEnemySpeed;
    }

    // Prevent enemies spawning too close

    float GetBetterSpawnX()
    {
        float randomX =
            Random.Range(
                -5f,
                5f
            );

        if (
            Mathf.Abs(
                randomX -
                lastSpawnX
            ) < 1.5f
        )
        {
            randomX =
                -lastSpawnX;
        }

        lastSpawnX =
            randomX;

        return randomX;
    }

    // Spawn powerups

    void SpawnPowerUp()
    {
        float randomX =
            Random.Range(
                -4.5f,
                4.5f
            );

        Vector3 spawnPosition =
            new Vector3(
                randomX,
                5f,
                0f
            );

        Instantiate(
            powerUpPrefab,
            spawnPosition,
            Quaternion.identity
        );
    }
}