using UnityEngine;
using UnityEngine.UI;

public class DamageFlash : MonoBehaviour
{
    // UI image used for screen flash effect

    public Image flashImage;

    // Controls how quickly flash fades

    public float flashSpeed = 5f;

    // Desired transparency value

    private float targetAlpha = 0f;

    void Update()
    {
        // Smoothly transition current alpha
        // toward target alpha value

        Color color =
            flashImage.color;

        color.a =
            Mathf.Lerp(
                color.a,
                targetAlpha,
                Time.deltaTime *
                flashSpeed
            );

        flashImage.color =
            color;
    }

    // Trigger flash effect

    public void Flash()
    {
        // Set visible flash intensity

        targetAlpha = 0.5f;

        // Return to transparent shortly after

        Invoke(
            "ResetFlash",
            0.1f
        );
    }

    // Remove flash effect

    void ResetFlash()
    {
        targetAlpha = 0f;
    }
}